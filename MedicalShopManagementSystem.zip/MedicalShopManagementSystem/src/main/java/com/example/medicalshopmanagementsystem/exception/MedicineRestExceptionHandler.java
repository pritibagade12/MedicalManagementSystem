package com.example.medicalshopmanagementsystem.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class MedicineRestExceptionHandler {

	//add exception handling code here
	
	//add exception handler using @ExceptionHandler
	@ExceptionHandler
	public ResponseEntity<MedicineErrorResponse> handleException(MedicineNotFoundException exc){
		//Create a MedicineErrorResponse
		MedicineErrorResponse error=new MedicineErrorResponse();
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setMessage(exc.getMessage());
		error.setTimeStamp(System.currentTimeMillis());
		
		//return ResponseEntity
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		}
	
	@ExceptionHandler
	public ResponseEntity<MedicineErrorResponse> handlerException(AdminNotFoundException exc){
		MedicineErrorResponse error=new MedicineErrorResponse();
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setMessage(exc.getMessage());
		error.setTimeStamp(System.currentTimeMillis());
		
		//return ResponseEntity
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		
	}
	
	@ExceptionHandler
	public ResponseEntity<MedicineErrorResponse> handlerException(CompanyNotFoundException exc){
		MedicineErrorResponse error=new MedicineErrorResponse();
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setMessage(exc.getMessage());
		error.setTimeStamp(System.currentTimeMillis());
		
		//return ResponseEntity
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		
	}
	
	@ExceptionHandler
	public ResponseEntity<MedicineErrorResponse> handlerException(CustomerNotFoundException exc){
		MedicineErrorResponse error=new MedicineErrorResponse();
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setMessage(exc.getMessage());
		error.setTimeStamp(System.currentTimeMillis());
		
		//return ResponseEntity
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		
	}
	
	@ExceptionHandler
	public ResponseEntity<MedicineErrorResponse> handlerException(SalesNotFoundException exc){
		MedicineErrorResponse error=new MedicineErrorResponse();
		error.setStatus(HttpStatus.NOT_FOUND.value());
		error.setMessage(exc.getMessage());
		error.setTimeStamp(System.currentTimeMillis());
		
		//return ResponseEntity
		return new ResponseEntity<>(HttpStatus.NOT_FOUND);
		
	}
	
	//add another exception handler - to catch any type of exception (catch all)
	@ExceptionHandler
	public ResponseEntity<MedicineErrorResponse> handleException(Exception exc){
		
		//create a MedicineErrorResponse
		MedicineErrorResponse error=new MedicineErrorResponse();
		error.setStatus(HttpStatus.BAD_REQUEST.value());
		error.setMessage(exc.getMessage());
		error.setTimeStamp(System.currentTimeMillis());
		
		//return responseEntity
		return new ResponseEntity<>(HttpStatus.BAD_REQUEST);
}
}