package com.example.medicalshopmanagementsystem.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.medicalshopmanagementsystem.dao.SalesRepository;
import com.example.medicalshopmanagementsystem.entity.Sales;
import com.example.medicalshopmanagementsystem.exception.SalesNotFoundException;
import com.example.medicalshopmanagementsystem.service.SalesService;

@RestController
@RequestMapping("/api")
public class SalesRestController {

	private SalesService salesService;
	
	@Autowired
	public SalesRestController(SalesService theSalesService) {
		salesService=theSalesService;
	}
	
	@GetMapping("/sales")
	public List<Sales> findAll(){
		return salesService.findAll();	
	}
	
	@GetMapping("/sales/{salesId}")
	public Sales getSales(@PathVariable int salesId) {
		Sales theSales=salesService.findById(salesId);
		if(theSales==null) {
			throw new SalesNotFoundException("Sales id not found :"+salesId);
		}
		return theSales;
	}
	
	@PostMapping("/sales")
	public Sales addSales(@RequestBody Sales theSales) {
		theSales.setSalesId(0);
		salesService.save(theSales);
		return theSales;
	}
	
	@PutMapping("/Sales")
	public Sales updateSales(@RequestBody Sales theSales) {
		salesService.save(theSales);
		return theSales;
	}
	
	@DeleteMapping("/sales/{salesId}")
	public String deleteSales(@PathVariable int salesId) {
		
	String deletedSales=salesService.deleteById(salesId);
	return deletedSales;
	}
}
