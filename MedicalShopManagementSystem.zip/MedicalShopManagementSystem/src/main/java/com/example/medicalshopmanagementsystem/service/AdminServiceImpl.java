package com.example.medicalshopmanagementsystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.medicalshopmanagementsystem.dao.AdminRepository;
import com.example.medicalshopmanagementsystem.entity.Admin;
import com.example.medicalshopmanagementsystem.exception.AdminNotFoundException;
@Service
public class AdminServiceImpl implements AdminService{

	private AdminRepository adminRepository;
	
	@Autowired
	public AdminServiceImpl(AdminRepository theAdminRepository) {
		adminRepository=theAdminRepository;
	}
	
	@Override
	public List<Admin> findAll() {
		// TODO Auto-generated method stub
		return adminRepository.findAll();
	}

	@Override
	public Admin findById(int theId) {
		// TODO Auto-generated method stub
		Optional<Admin> result=adminRepository.findById(theId);
		Admin theAdmin=null;
		if(result.isPresent()) {
			theAdmin=result.get();
		}else {
			throw new AdminNotFoundException("Did not find the admin id :"+theId);
		}
		return theAdmin;
	}

	@Override
	public void save(Admin theAdmin) {
		// TODO Auto-generated method stub
		adminRepository.save(theAdmin);
	}

	@Override
	public String deleteById(int theId) {
		// TODO Auto-generated method stub
		Optional<Admin> result=Optional.empty();
		String theAdmin=null;
		if(result.isPresent()) {
			
			throw new AdminNotFoundException("Did not find the admin id :"+theId);
		}
		adminRepository.deleteById(theId);
		return theAdmin;
	}

	
}
