package com.example.medicalshopmanagementsystem.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.medicalshopmanagementsystem.dao.CompanyRepository;
import com.example.medicalshopmanagementsystem.entity.Company;
import com.example.medicalshopmanagementsystem.exception.CompanyNotFoundException;
import com.example.medicalshopmanagementsystem.service.CompanyService;

@RestController
@RequestMapping("/companies")
public class CompanyRestController {

	private CompanyService companyService;
	
	@Autowired
	public CompanyRestController(CompanyService theCompanyService) {
		companyService=theCompanyService;
	}
	
	@GetMapping("/companies")
	public List<Company> findAll() {
		return companyService.findAll();
	}
	
	@GetMapping("/companies/{companyId}")
	public Company getCompany(@PathVariable int companyId) {
	Company theCompany=companyService.findById(companyId);
		if(theCompany==null) {
			throw new CompanyNotFoundException("Company id not found :"+companyId);
		}
	return theCompany;
	}
	
	@PostMapping("/companies")
	public Company addCompany(@RequestBody Company theCompany) {
		theCompany.setCompanyId(0);
		companyService.save(theCompany);
		return theCompany;
	}
	
	@PutMapping("/companies")
	public Company updateCompany(@RequestBody Company theCompany) {
		companyService.save(theCompany);
		return theCompany;
	}
	
	@DeleteMapping("/companies/{companyId}")
	public String deleteCompany(@PathVariable int companyId) {
			String deletedCompany=companyService.deleteById(companyId);
			return deletedCompany;
		}
	}

