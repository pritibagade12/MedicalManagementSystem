package com.example.medicalshopmanagementsystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.medicalshopmanagementsystem.dao.CompanyRepository;
import com.example.medicalshopmanagementsystem.entity.Company;
import com.example.medicalshopmanagementsystem.exception.CompanyNotFoundException;
@Service
public class CompanyServiceImpl implements CompanyService {

	private CompanyRepository companyRepository;
	
	@Autowired
	public CompanyServiceImpl(CompanyRepository theCompanyRepository) {
		companyRepository=theCompanyRepository;
	}

	@Override
	public List<Company> findAll() {
		// TODO Auto-generated method stub
		return companyRepository.findAll();
	}

	@Override
	public Company findById(int theId) {
		// TODO Auto-generated method stub
		Optional<Company> result=companyRepository.findById(theId);
		Company theCompany=null;
		if(result.isPresent()) {
			theCompany=result.get();
		}
		else {
			throw new CompanyNotFoundException("Did not find company id :"+theId);
		}
		return theCompany;
	}

	@Override
	public void save(Company theCompany) {
		// TODO Auto-generated method stub
		companyRepository.save(theCompany);
	}

	@Override
	public String deleteById(int theId) {
		// TODO Auto-generated method stub
		Optional<Company> result=companyRepository.findById(theId);
		String theCompany=null;
		if(result.isPresent()) {
			
			throw new CompanyNotFoundException("Did not find company id :"+theId);
		}
		companyRepository.deleteById(theId);
		return theCompany;
	}

	
	

	@Override
	public CompanyRepository findByCompanyName(String companyName) {
		// TODO Auto-generated method stub
		return null;
	}

	

}
