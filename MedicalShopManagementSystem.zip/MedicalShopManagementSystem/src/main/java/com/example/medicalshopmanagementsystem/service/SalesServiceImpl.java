package com.example.medicalshopmanagementsystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.medicalshopmanagementsystem.dao.SalesRepository;
import com.example.medicalshopmanagementsystem.entity.Sales;
import com.example.medicalshopmanagementsystem.exception.SalesNotFoundException;
@Service
public class SalesServiceImpl implements SalesService{

	private SalesRepository salesRepository;
	
	@Autowired
	public SalesServiceImpl(SalesRepository theSalesRepository) {
		salesRepository=theSalesRepository;
	}
	
	@Override
	public List<Sales> findAll() {
		// TODO Auto-generated method stub
		return salesRepository.findAll();
	}

	@Override
	public Sales findById(int theId) {
		// TODO Auto-generated method stub
		Optional<Sales> result=salesRepository.findById(theId);
		Sales theSales=null;
		if(result.isPresent()) {
			theSales=result.get();
		}else {
			throw new SalesNotFoundException("Did not find by sales id :"+theId);
		}
		return theSales;
	}

	@Override
	public void save(Sales theSales) {
		// TODO Auto-generated method stub
		salesRepository.save(theSales);
	}




	@Override
	public String deleteById(int theID) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public SalesRepository findBySalesId(int salesId) {
		// TODO Auto-generated method stub
		return null;
	}

}
