package com.example.medicalshopmanagementsystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="sales")
public class Sales {

	@OneToMany
	@JoinColumn(name="medicine_id" , nullable = false)
	private int medicineId;
	
	@OneToMany
	@JoinColumn(name="customer_id" , nullable = false)
	private int customerId;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="sales_id")
	private int salesId;
	
	@Column(name="sales_name")
	private String salesName;
	
	@Column(name="total_cost")
	private long totalCost;
	
	@Column(name="bill_number")
	private long billNumber;

	public Sales() {
		super();
	}

	public Sales(int salesId, String salesName, long totalCost, long billNumber) {
		super();
		this.salesId = salesId;
		this.salesName = salesName;
		this.totalCost = totalCost;
		this.billNumber = billNumber;
	}

	public int getSalesId() {
		return salesId;
	}

	public void setSalesId(int salesId) {
		this.salesId = salesId;
	}

	public String getSalesName() {
		return salesName;
	}

	public void setSalesName(String salesName) {
		this.salesName = salesName;
	}

	public long getTotalCost() {
		return totalCost;
	}

	public void setTotalCost(long totalCost) {
		this.totalCost = totalCost;
	}

	public long getBillNumber() {
		return billNumber;
	}

	public void setBillNumber(long billNumber) {
		this.billNumber = billNumber;
	}

	@Override
	public String toString() {
		return "Sales [salesId=" + salesId + ", salesName=" + salesName + ", totalCost=" + totalCost + ", billNumber="
				+ billNumber + "]";
	}
	
	
	
}
