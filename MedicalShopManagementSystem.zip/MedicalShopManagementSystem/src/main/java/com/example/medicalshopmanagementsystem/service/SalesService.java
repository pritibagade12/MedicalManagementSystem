package com.example.medicalshopmanagementsystem.service;

import java.util.List;

import com.example.medicalshopmanagementsystem.dao.SalesRepository;
import com.example.medicalshopmanagementsystem.entity.Sales;

public interface SalesService {

	public List<Sales> findAll();
	
	public Sales findById(int theId);
	
	public void save(Sales theSales);
	
	public String deleteById(int theID);
	
	SalesRepository findBySalesId(int salesId);
}
