package com.example.medicalshopmanagementsystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.medicalshopmanagementsystem.dao.CustomerRepository;
import com.example.medicalshopmanagementsystem.entity.Customer;
import com.example.medicalshopmanagementsystem.exception.CustomerNotFoundException;
@Service
public class CustomerServiceImpl implements CustomerService {

	private CustomerRepository customerRepository;
	
	@Autowired
	public CustomerServiceImpl(CustomerRepository theCustomerRepository) {
		customerRepository=theCustomerRepository;
	}
	
	@Override
	public List<Customer> findAll() {
		// TODO Auto-generated method stub
		return customerRepository.findAll();
	}

	@Override
	public Customer findById(int theId) {
		// TODO Auto-generated method stub
		Optional<Customer> result=customerRepository.findById(theId);
		Customer theCustomer=null;
		if(result.isPresent()) {
			theCustomer=result.get();
		}else {
			throw new CustomerNotFoundException("Did not find the customer id :"+theId);
		}
		return theCustomer;
	}

	@Override
	public void save(Customer theCustomer) {
		// TODO Auto-generated method stub
		customerRepository.save(theCustomer);
	}

		@Override
	public String deleteById(int theId) {
		// TODO Auto-generated method stub
		return deleteById(theId);
	}

	@Override
	public CustomerRepository findByCustomerAddress(String customerAddress) {
		// TODO Auto-generated method stub
		return null;
	}

	
}
