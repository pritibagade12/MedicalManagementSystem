package com.example.medicalshopmanagementsystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.medicalshopmanagementsystem.dao.MedicineRepository;
import com.example.medicalshopmanagementsystem.entity.Medicine;
import com.example.medicalshopmanagementsystem.exception.MedicineNotFoundException;
@Service
public class MedicineServiceImpl implements MedicineService {

	private MedicineRepository medicineRepository;
	
	@Autowired
	public MedicineServiceImpl(MedicineRepository theMedicineRepository) {
		medicineRepository=theMedicineRepository;
	}
	
	@Override
	public List<Medicine> findAll() {
		// TODO Auto-generated method stub
		return medicineRepository.findAll();
	}

	@Override
	public Medicine findById(int theId) {
		// TODO Auto-generated method stub
		Optional<Medicine> result=medicineRepository.findById(theId);
		Medicine theMedicine=null;
		if(result.isPresent())
		{
			theMedicine=result.get();
		}
		else 
		{
			throw new MedicineNotFoundException("Did not find the medicine id :"+theId);
		}
		return theMedicine;
	}

	@Override
	public void save(Medicine theMedicine) {
		// TODO Auto-generated method stub
		medicineRepository.save(theMedicine);
	}

	@Override
	public String deleteById(int theId) {
		// TODO Auto-generated method stub
		medicineRepository.deleteById(theId);
		return null;
	}

	@Override
	public MedicineRepository findByMedicineName(String medicineName) {
		// TODO Auto-generated method stub
		return null;
	}

}
