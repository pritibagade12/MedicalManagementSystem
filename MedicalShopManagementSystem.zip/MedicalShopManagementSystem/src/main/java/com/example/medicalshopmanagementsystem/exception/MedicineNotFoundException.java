package com.example.medicalshopmanagementsystem.exception;

public class MedicineNotFoundException extends RuntimeException {

	public MedicineNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public MedicineNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public MedicineNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
