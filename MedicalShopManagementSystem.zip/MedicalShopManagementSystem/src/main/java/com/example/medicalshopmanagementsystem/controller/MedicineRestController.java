package com.example.medicalshopmanagementsystem.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.medicalshopmanagementsystem.dao.MedicineRepository;
import com.example.medicalshopmanagementsystem.entity.Medicine;
import com.example.medicalshopmanagementsystem.exception.MedicineNotFoundException;
import com.example.medicalshopmanagementsystem.service.MedicineService;

@RestController
@RequestMapping("/api")
public class MedicineRestController {

	private MedicineService medicineService;
	
	@Autowired
	public MedicineRestController(MedicineService theMedicineService) {
		medicineService=theMedicineService;
	}
	
	@GetMapping("/medicines")
	public List<Medicine> findAll(){
		return medicineService.findAll();
	}
	
	@GetMapping("/medicines/{medicineId}")
	public Medicine getMedicine(@PathVariable int medicineId) {
		Medicine theMedicine=medicineService.findById(medicineId);
		if(theMedicine==null) {
			throw new MedicineNotFoundException("Medicine id not found :"+medicineId);
		}
		return theMedicine;
	}
	
	@PostMapping("/medicines")
	public Medicine addMedicine(@RequestBody Medicine theMedicine) {
		theMedicine.setMedicineId(0);
		medicineService.save(theMedicine);
		return theMedicine;
	}
	
	@PutMapping("/medicines")
	public Medicine updateMedicine(@RequestBody Medicine theMedicine) {
		medicineService.save(theMedicine);
		return theMedicine;
	}
	
	@DeleteMapping("/medicines/{medicineId}")
	public String deleteMedicine(@PathVariable int medicineId) {
		String deletedMedicine=medicineService.deleteById(medicineId);
		return deletedMedicine;
	}
}
