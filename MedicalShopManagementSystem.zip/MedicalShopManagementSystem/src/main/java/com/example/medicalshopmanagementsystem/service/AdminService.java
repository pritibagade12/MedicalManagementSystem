package com.example.medicalshopmanagementsystem.service;

import java.util.List;

import com.example.medicalshopmanagementsystem.entity.Admin;

public interface AdminService {

	public List<Admin> findAll();
	
	public Admin findById(int theId);
	
	public void save(Admin theAdmin);
	
	public String deleteById(int theId);
}
