package com.example.medicalshopmanagementsystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.medicalshopmanagementsystem.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, Integer> {

	CustomerRepository findByCustomerAddress(String customerAddress);

}
