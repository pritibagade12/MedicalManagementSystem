package com.example.medicalshopmanagementsystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.medicalshopmanagementsystem.entity.Company;

public interface CompanyRepository extends JpaRepository<Company, Integer>{

	CompanyRepository findByCompanyName (String companyName);

	
}
