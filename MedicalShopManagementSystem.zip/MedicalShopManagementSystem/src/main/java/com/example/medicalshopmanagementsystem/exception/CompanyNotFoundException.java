package com.example.medicalshopmanagementsystem.exception;

public class CompanyNotFoundException extends RuntimeException{

	public CompanyNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public CompanyNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public CompanyNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

	}
