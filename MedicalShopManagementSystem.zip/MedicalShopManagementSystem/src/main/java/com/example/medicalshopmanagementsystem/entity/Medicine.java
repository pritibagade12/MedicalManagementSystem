package com.example.medicalshopmanagementsystem.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="medicines")
public class Medicine {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="medicine_Id")
	private int medicineId;
	
	@Column(name="medicine_name")
	private String medicineName;
	
	@OneToMany
	@JoinColumn(name="company_name" , nullable = false)
	@Column(name="company_name")
	private String companyName;
	
	@Column(name="quantity")
	private long quantity;
	
	@Column(name="costPerUnit")
	private long costPerUnit;

	public Medicine() {
		
	}

	public Medicine(int medicineId, String medicineName, String companyName, long quantity, long costPerUnit) {
		super();
		this.medicineId = medicineId;
		this.medicineName = medicineName;
		this.companyName = companyName;
		this.quantity = quantity;
		this.costPerUnit = costPerUnit;
	}

	public int getMedicineId() {
		return medicineId;
	}

	public void setMedicineId(int medicineId) {
		this.medicineId = medicineId;
	}

	public String getMedicineName() {
		return medicineName;
	}

	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public long getQuantity() {
		return quantity;
	}

	public void setQuantity(long quantity) {
		this.quantity = quantity;
	}

	public long getCostPerUnit() {
		return costPerUnit;
	}

	public void setCostPerUnit(long costPerUnit) {
		this.costPerUnit = costPerUnit;
	}

	@Override
	public String toString() {
		return "Medicine [medicineId=" + medicineId + ", medicineName=" + medicineName + ", companyName=" + companyName
				+ ", quantity=" + quantity + ", costPerUnit=" + costPerUnit + "]";
	}

	
	
}
