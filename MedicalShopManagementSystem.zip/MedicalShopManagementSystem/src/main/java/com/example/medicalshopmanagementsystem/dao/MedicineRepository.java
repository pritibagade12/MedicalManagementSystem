package com.example.medicalshopmanagementsystem.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.medicalshopmanagementsystem.entity.Company;
import com.example.medicalshopmanagementsystem.entity.Medicine;

public interface MedicineRepository extends JpaRepository<Medicine, Integer> {

	MedicineRepository findByMedicineName(String medicineName);
}
